package wox

type Transaction struct {
    From     string
    To       string
    Value    string
    Gas      string
    GasPrice string
    Data     string
}
